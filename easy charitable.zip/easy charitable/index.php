<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
		integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
		integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<!--Load hover.css-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/hover.css/2.3.1/css/hover-min.css"
		type="text/css" />
	<!--Load CSS File-->
	<link rel="stylesheet" href="assets/css/style.css" type="text/css">

	<title>EASY CHARITABLE</title>
</head>

<body>
	<header>
		<nav class="navbar navbar-expand-sm  navbar-light fixed-top">

			<!--<div class="collapse navbar-collapse" id="navbarSupportedContent">-->
			<a href="index.html" class="navbar-brand navBrandColor">EASY CHARITABLE</a>

			<button class="navbar-toggler ml-auto" data-toggle="collapse" data-target="#navbarNavDropdown" aria-expanded="navbarNavDropdown" aria-controls="false">

            <span class="navbar-toggler-icon"></span></button>

			<div class="collapse navbar-collapse" id="navbarNavDropdown">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item active">
						<a href="index.html" class="nav-link hvr-shutter-out-vertical">Home</a>
					</li>
					<li class="nav-item">
						<a href="map.html" class="nav-link hvr-shutter-out-vertical">Map</a>
					</li>
				 	<li class="nav-item">
						<a href="donate.html" class="nav-link hvr-shutter-out-vertical">Donate</a>
					</li>
					<li class="nav-item">
						<a href="contact.html" class="nav-link hvr-shutter-out-vertical">Contacts</a>
					</li>
				</ul>
			</div>
		</nav>
	</header>
	<article>

		<!--Section 1: Title Page-->

		<section class="hpimg-1" title="A background picture of a child that looks sad and sits on the ground">
			<div id="textEffect">
				<div class="container-fluid">
					<div class="row">
						<div class="col-11 col-xl-8">
							<div class="top-section textHP1 text-center">
								<h1>"It is not how much we give, but how much love we put into giving." <br />- Mother Teresa</h1>
								<p class="text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
									<br />
									
								</p>
							</div>
						</div>
					</div>
					<!--<div class="row">
						<div class="col-11 col-xl-8">
							<div class="top-section-counter-BG text-center textHP1">
								<div id="counter"></div>
								<div id="death"></div>
							</div>
						</div>
					</div>-->
				</div>
			</div>
		</section>


		<!--Section 2-->

		<section class="hpimg-2" title="A background picture of a child hugging another, while both of them are looking at the camera and standing in dirt">
			<div class="container-fluid section">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2>Introduction</h2>
						<p class="text ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. <a
								href=" ">here!</a>
						</p>
					</div>
				</div>
			</div>
		</section>

		<!--Section 3: The Struggle for Food and Health Care-->

		<section class="hpimg-3" title="A background picture of three children with empty cups in their hands and standing by a wall, while looking sad">
			<div class="container-fluid section">
				<div class="row">
					<div class="col-sm-12 text-center">
						<h2>The Struggle for Food and Health Care</h2>
						<p class="text">In some countries, a single plate of food can even cost up to around 70$ or
							even about 200$. About 45% children, under the age of five, are caused to pass away, due
							to malnutrition. In many countries, people live in slums,
							ran away, suffer mentally and physically from wars, got affected by natural disasters,
							etc. <span id="dots1" class="dots">...</span><span id="more1" class="more">So, they do not have much access to nutritions, medications or shelter and require various
                                kinds of support!
                            </span>
							<button id="readBtn1" class="readBtn">Read More</button></p>
					</div>
				</div>
			</div>
		</section>

		<!--Section 4: Charity Foundations-->

		<section class="hpimg-4" title="A background picture of a child that is so thin that its ribs can be seen, while it is surrounded by people">
			<div class="container-fluid section">
				<div class="row">
					<div class="col-sm-12 mx-auto text-center">
							<h2>Charity Foundations</h2>
							<p class="text">
								The GDP per capital and GDP growth play huge roles in a country's economic status, as
								they show measurements of a country's standard of living, how prosperous the citizens of
								a country feel, and how fast a country's economy is growing.
								<span id="dots2" class="dots">...</span><span id="more2" class="more">These are very low
                                in many countries as there are multiple problems, such as the status of their labour, lands, capital and enterprises. 
								<button id="readBtn2" class="readBtn">Read More</button>
							</p>

							<p class="MotherTeresaQuote text-center">
								"It is not how much we give, but how much love we put into giving." <br />- Mother Teresa
                            </p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!--Section 5:  Donate-->

		<section class="hpimg-5" title="A background picture of a child that looks sad and sits on the ground">
			<div class="container section">
				<div class="row">
					<div class="col-12">
						<div class=" scroll-effect">
							<h2>JOIN US NOW</h2>
							<p class="text">Welcome</p>
							<a href="donate.html" class="btn btn-primary donateButtonStyleHP">Donate</a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</article>

    <!-- Aside bar -->
	<aside>
		<div>
			<ul class="social-media-button d-none d-sm-block">
				<li class="facebook-aside"><a href="http://www.facebook.com" target="_blank"
						class="facebook"><i class="fab fa-facebook"></i></a></li>
				<li class="twitter-aside"><a href="http://www.twitter.com" target="_blank"
						class="twitter"><i class="fab fa-twitter"></i></a></li>
				<li class="youtube-aside"><a href="http://www.youtube.com" target="_blank"
						class="youtube"><i class="fab fa-youtube"></i></a></li>
				<li class="instagram-aside"><a href="http://www.instagram.com" target="_blank"
						class="instagram"><i class="fab fa-instagram"></i></a></li>
			</ul>
		</div>
	</aside>

    <!-- Footer -->
	<footer id="footer">
		<div class="container-fluid">
			<div class="row">
				<div class="col-12 col-sm-6 text-center">
					<ul class="footer-list">
						<li><a href="tel: 12 3456 7890" class="footer-link">Phone number: 12 4567 7890</li>
						<li><a href="contact.html" class="footer-link">Send Me a Message</a></li>
					</ul>
				</div>
				<div class="col-12 col-sm-6 text-center">
					<ul class="footer-list">
						<li><a href="donate.html" class="footer-link">Donate</a></li>
						<li><a href="map.html" class="footer-link">Map</a></li>
					</ul>
				</div>
			</div>
		</div>

		<div class="d-block d-sm-none">
			<hr>

			<!--Footer Social Media Icons-->

			<div class="container-fluid">
				<div class="row">
					<div class="col-12">
						<ul class="social-media-icons-footer">
							<li class="facebook-footer"><a href="http://www.facebook.com"
									target="_blank"><i class="fab fa-facebook"></i></a></li>
							<li class="twitter-footer"><a href="http://www.twitter.com"
									target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li class="youtube-footer"><a href="http://www.youtube.com"
									target="_blank"><i class="fab fa-youtube"></i></a></li>
							<li class="instagram-footer"><a href="http://www.instagram.com"
									target="_blank"><i class="fab fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>


	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
		integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
	</script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
		integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous">
	</script>

	<script src="assets/js/homepage.js"></script>
</body>

</html>