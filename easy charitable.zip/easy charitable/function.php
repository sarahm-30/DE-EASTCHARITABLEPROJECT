<?php
class contact{
    private $host="localhost";
    private $user="root";
    private $pass="";
    private $db="contact";
    public $mysqli;

    public function _construct(){
        return $this->mysqli=new mysqli($this->user,$this->pass,$this->db);

    }

    public function contact_us($data){
        $fname=$data['name'];
        $email=$data['email'];
        $message=$data['message'];
        $q="insert into contact_us set first_name='$fnmame',email='$email',message='$message'";
        return $this->mysqli->query($q);
    }
}
?>